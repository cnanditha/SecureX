// -----------------------------------------------------------------------
// Usage: node verify-tamper-demo.js <tokenId> <filePath>
// Example: node verify-tamper-demo.js 4 sample.pdf
//
// Fetches the recorded fileHash for the given tokenId directly from the
// deployed contract (no manual copy-pasting), computes SHA-256 of the
// file you point it at, and reports whether they match — the exact same
// check the backend's /api/decrypt-asset endpoint performs.
//
// Reuses this folder's .env (CONTRACT_ADDRESS, SEPOLIA_RPC_URL) — run
// this from inside secureasset-backend / securex-backend.
// -----------------------------------------------------------------------

require('dotenv').config();
const crypto = require('crypto');
const fs = require('fs');
const { ethers } = require('ethers');

const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS;
const SEPOLIA_RPC_URL =
  process.env.SEPOLIA_RPC_URL || 'https://ethereum-sepolia-rpc.publicnode.com';

const READ_ABI = [
  'function assets(uint256 tokenId) view returns (string fileHash, string signature, string ipfsCID, uint256 releaseTime, uint256 sharesSubmitted, uint256 threshold, bool released)',
];

async function main() {
  const [tokenId, filePath] = process.argv.slice(2);

  if (!tokenId || !filePath) {
    console.error('Usage: node verify-tamper-demo.js <tokenId> <filePath>');
    console.error('Example: node verify-tamper-demo.js 4 sample.pdf');
    process.exit(1);
  }
  if (!CONTRACT_ADDRESS) {
    console.error('CONTRACT_ADDRESS is not set in .env — cannot look up the asset.');
    process.exit(1);
  }
  if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    process.exit(1);
  }

  console.log(`Looking up asset #${tokenId} on-chain...`);
  const provider = new ethers.JsonRpcProvider(SEPOLIA_RPC_URL);
  const contract = new ethers.Contract(CONTRACT_ADDRESS, READ_ABI, provider);

  const onChain = await contract.assets(tokenId);
  const recordedHash = onChain.fileHash;

  if (!recordedHash) {
    console.error(`No asset found for tokenId ${tokenId}.`);
    process.exit(1);
  }

  const buffer = fs.readFileSync(filePath);
  const computedHash = crypto.createHash('sha256').update(buffer).digest('hex');

  console.log('');
  console.log('Recorded on-chain hash:', recordedHash);
  console.log('Computed hash of file: ', computedHash);
  console.log('');
  if (computedHash === recordedHash) {
    console.log('✅ MATCH — this file is exactly what was sealed at creation.');
  } else {
    console.log('❌ MISMATCH — this file has been altered since creation.');
  }
}

main().catch((err) => {
  console.error('Error:', err.message);
  process.exit(1);
});
