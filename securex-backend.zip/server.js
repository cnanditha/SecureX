require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { ethers } = require('ethers');
const lib = require('./crypto-lib');

const PORT = process.env.PORT || 3001;
const NUM_CUSTODIANS = Number(process.env.NUM_CUSTODIANS || 3);
const PINATA_JWT = process.env.PINATA_JWT;
const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS;
const SEPOLIA_RPC_URL = process.env.SEPOLIA_RPC_URL || 'https://ethereum-sepolia-rpc.publicnode.com';

if (!PINATA_JWT) {
  console.warn('[warn] PINATA_JWT is not set in .env — /api/create-asset will fail on IPFS upload.');
}
if (!CONTRACT_ADDRESS) {
  console.warn('[warn] CONTRACT_ADDRESS is not set in .env — /api/decrypt-asset cannot read on-chain state.');
}

// Minimal read-only ABI — this server only ever reads the contract,
// never signs a transaction. All writes happen from the connected
// wallet in the frontend, exactly as documented in the frontend README.
const READ_ABI = [
  'function assets(uint256 tokenId) view returns (string fileHash, string signature, string ipfsCID, uint256 releaseTime, uint256 sharesSubmitted, uint256 threshold, bool released)',
];

const provider = new ethers.JsonRpcProvider(SEPOLIA_RPC_URL);
const readContract = CONTRACT_ADDRESS
  ? new ethers.Contract(CONTRACT_ADDRESS, READ_ABI, provider)
  : null;

const app = express();
app.use(cors());
app.use(express.json());

const UPLOAD_DIR = path.join(__dirname, 'uploads');
const DOWNLOAD_DIR = path.join(__dirname, 'downloads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });

app.use('/downloads', express.static(DOWNLOAD_DIR));

const upload = multer({ dest: UPLOAD_DIR });

// -------------------------------------------------------------------------
// POST /api/create-asset
// multipart/form-data: file, releaseTime, threshold, adminAddress
// -> { hash, signature, cid }
// -------------------------------------------------------------------------
app.post('/api/create-asset', upload.single('file'), async (req, res) => {
  let tempPath;
  try {
    if (!req.file) {
      return res.status(400).send('No file uploaded.');
    }
    tempPath = req.file.path;
    const threshold = Number(req.body.threshold || 2);

    const fileBuffer = fs.readFileSync(tempPath);

    // Step 1 — hash + sign
    const ntaKeys = lib.loadOrCreateNtaKeys();
    const fileHash = lib.hashFile(fileBuffer);
    const signature = lib.signBuffer(fileBuffer, ntaKeys.privateKey);

    // Step 2 — AES-256 encrypt
    const { aesKey, iv, encrypted, authTag } = lib.aesEncrypt(fileBuffer);

    // Step 3 — upload the encrypted blob to IPFS via Pinata
    if (!PINATA_JWT) {
      return res.status(500).send('Server misconfigured: PINATA_JWT is not set.');
    }
    const form = new FormData();
    form.append('file', encrypted, { filename: 'encrypted.bin' });
    const pinataRes = await axios.post(
      'https://api.pinata.cloud/pinning/pinFileToIPFS',
      form,
      {
        maxBodyLength: Infinity,
        headers: { ...form.getHeaders(), Authorization: `Bearer ${PINATA_JWT}` },
      }
    );
    const cid = pinataRes.data.IpfsHash;

    // Step 4 — split the AES key (Shamir), wrap each share for its custodian
    const custodians = lib.loadOrCreateCustodians(NUM_CUSTODIANS);
    const shares = lib.splitKey(aesKey, NUM_CUSTODIANS, threshold);
    const wrappedShares = [];
    for (let i = 0; i < NUM_CUSTODIANS; i++) {
      const wrapped = await lib.wrapShare(shares[i], custodians[i].publicKey);
      wrappedShares.push({ custodianId: custodians[i].id, ...wrapped });
    }

    // Step 5 — persist everything needed to decrypt later, keyed by fileHash
    // (the tokenId doesn't exist yet — it's assigned on-chain by the
    // frontend's createAsset call, which happens right after this responds)
    lib.writeAssetRecord(fileHash, {
      fileHash,
      signature,
      iv: iv.toString('hex'),
      authTag: authTag.toString('hex'),
      ipfsCID: cid,
      threshold,
      numCustodians: NUM_CUSTODIANS,
      wrappedShares,
      ntaPublicKey: ntaKeys.publicKey,
      createdAt: Date.now(),
    });

    res.json({ hash: fileHash, signature, cid });
  } catch (err) {
    console.error('[create-asset] error:', err.message);
    res.status(500).send(err.message || 'Failed to create asset.');
  } finally {
    if (tempPath) fs.unlink(tempPath, () => {});
  }
});

// -------------------------------------------------------------------------
// POST /api/decrypt-asset
// json: { tokenId, requesterAddress }
// -> { hashMatch, signatureValid, downloadUrl? }
// -------------------------------------------------------------------------
app.post('/api/decrypt-asset', async (req, res) => {
  try {
    const { tokenId } = req.body;
    if (tokenId === undefined || tokenId === null) {
      return res.status(400).send('tokenId is required.');
    }
    if (!readContract) {
      return res.status(500).send('Server misconfigured: CONTRACT_ADDRESS is not set.');
    }

    // Step 1 — read the anchor off-chain to find which record this is
    const onChain = await readContract.assets(tokenId);
    const { fileHash, ipfsCID, released, threshold } = onChain;

    if (!released) {
      return res.status(400).json({
        error: 'This asset has not been released on-chain yet (time-lock and/or share threshold not met).',
      });
    }

    // Step 2 — find the matching encryption record saved at creation time
    const record = lib.getAssetRecord(fileHash);
    if (!record) {
      return res.status(404).send('No local encryption record found for this asset.');
    }

    // Step 3 — unwrap enough shares to hit the threshold, then combine
    // (In this prototype, custodian private keys live together in
    // data/custodians.json for simulation purposes. In a real deployment,
    // each custodian would submit their own unwrapped share independently
    // instead of the backend holding every key.)
    const neededCount = Number(threshold);
    const sharesToUse = record.wrappedShares.slice(0, neededCount);
    const custodians = lib.loadOrCreateCustodians(record.numCustodians);

    const rawShares = [];
    for (const wrapped of sharesToUse) {
      const custodian = custodians.find((c) => c.id === wrapped.custodianId);
      const rawShare = await lib.unwrapShare(wrapped, custodian.privateKey);
      rawShares.push(rawShare);
    }
    const aesKey = lib.combineShares(rawShares);

    // Step 4 — fetch the encrypted file from IPFS
    const gatewayUrl = `https://gateway.pinata.cloud/ipfs/${record.ipfsCID}`;
    const ipfsRes = await axios.get(gatewayUrl, { responseType: 'arraybuffer' });
    const encryptedBuffer = Buffer.from(ipfsRes.data);

    // Step 5 — decrypt
    const iv = Buffer.from(record.iv, 'hex');
    const authTag = Buffer.from(record.authTag, 'hex');
    let decryptedBuffer;
    try {
      decryptedBuffer = lib.aesDecrypt(encryptedBuffer, aesKey, iv, authTag);
    } catch (decryptErr) {
      return res.json({ hashMatch: false, signatureValid: false });
    }

    // Step 6 — verify hash + signature
    const recomputedHash = lib.hashFile(decryptedBuffer);
    const hashMatch = recomputedHash === record.fileHash && recomputedHash === fileHash;
    const signatureValid = lib.verifyBuffer(decryptedBuffer, record.ntaPublicKey, record.signature);

    let downloadUrl;
    if (hashMatch && signatureValid) {
      const filename = `asset-${tokenId}-${Date.now()}.pdf`;
      fs.writeFileSync(path.join(DOWNLOAD_DIR, filename), decryptedBuffer);
      downloadUrl = `${req.protocol}://${req.get('host')}/downloads/${filename}`;
    }

    res.json({ hashMatch, signatureValid, downloadUrl });
  } catch (err) {
    console.error('[decrypt-asset] error:', err.message);
    res.status(500).send(err.message || 'Failed to decrypt asset.');
  }
});

app.get('/api/health', (req, res) => res.json({ ok: true }));

// -------------------------------------------------------------------------
// Off-chain integrity check log. Hashing happens in the browser (Web
// Crypto API) — this just records the result so Admin and the Audit Log
// page can see it. NOT blockchain-anchored; the actual tamper-evidence
// guarantee is the hash already anchored on-chain at asset creation.
// -------------------------------------------------------------------------
app.post('/api/integrity-log', (req, res) => {
  try {
    const { tokenId, checkerAddress, computedHash, recordedHash, matched } = req.body;
    if (tokenId === undefined || !computedHash || !recordedHash) {
      return res.status(400).send('tokenId, computedHash, and recordedHash are required.');
    }
    const entry = lib.appendIntegrityLog({
      tokenId: String(tokenId),
      checkerAddress: checkerAddress || null,
      computedHash,
      recordedHash,
      matched: !!matched,
      timestamp: Date.now(),
    });
    res.json(entry);
  } catch (err) {
    console.error('[integrity-log] error:', err.message);
    res.status(500).send(err.message || 'Failed to log integrity check.');
  }
});

app.get('/api/integrity-log', (req, res) => {
  try {
    const log = lib.readIntegrityLog();
    const { tokenId } = req.query;
    const filtered = tokenId ? log.filter((e) => e.tokenId === String(tokenId)) : log;
    res.json(filtered);
  } catch (err) {
    console.error('[integrity-log] error:', err.message);
    res.status(500).send(err.message || 'Failed to read integrity log.');
  }
});

app.listen(PORT, () => {
  console.log(`SecureX backend listening on http://localhost:${PORT}`);
  if (!CONTRACT_ADDRESS) console.log('  -> set CONTRACT_ADDRESS in .env');
  if (!PINATA_JWT) console.log('  -> set PINATA_JWT in .env');
});
