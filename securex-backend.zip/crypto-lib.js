// -----------------------------------------------------------------------
// All the crypto primitives, reused as plain functions from your
// existing create-asset.js / decrypt-asset.js scripts. server.js calls
// these — nothing here talks to Express or the blockchain directly.
// -----------------------------------------------------------------------

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const secrets = require('shamirs-secret-sharing');
const eccrypto = require('eccrypto');

const DATA_DIR = path.join(__dirname, 'data');
const NTA_KEYS_PATH = path.join(DATA_DIR, 'nta-keys.json');
const CUSTODIANS_PATH = path.join(DATA_DIR, 'custodians.json');
const ASSETS_DB_PATH = path.join(DATA_DIR, 'assets-db.json');
const INTEGRITY_LOG_PATH = path.join(DATA_DIR, 'integrity-log.json');

// ---- NTA signing key pair (load or create once) ------------------------

function loadOrCreateNtaKeys() {
  if (fs.existsSync(NTA_KEYS_PATH)) {
    return JSON.parse(fs.readFileSync(NTA_KEYS_PATH, 'utf8'));
  }
  const keys = crypto.generateKeyPairSync('ec', {
    namedCurve: 'secp256k1',
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(NTA_KEYS_PATH, JSON.stringify(keys));
  return keys;
}

// ---- Custodian key pairs (load or create once, N=3) ---------------------

function loadOrCreateCustodians(numCustodians) {
  if (fs.existsSync(CUSTODIANS_PATH)) {
    return JSON.parse(fs.readFileSync(CUSTODIANS_PATH, 'utf8'));
  }
  const custodians = [];
  for (let i = 1; i <= numCustodians; i++) {
    const privateKey = eccrypto.generatePrivate();
    const publicKey = eccrypto.getPublic(privateKey);
    custodians.push({
      id: i,
      privateKey: privateKey.toString('hex'),
      publicKey: publicKey.toString('hex'),
    });
  }
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(CUSTODIANS_PATH, JSON.stringify(custodians));
  return custodians;
}

// ---- Tiny local "database": fileHash -> encryption record ----------------
// NOTE: this is a prototype-grade JSON file, not a real database.
// Good enough for a hackathon demo; swap for a real DB before production.

function readAssetsDb() {
  if (!fs.existsSync(ASSETS_DB_PATH)) return {};
  return JSON.parse(fs.readFileSync(ASSETS_DB_PATH, 'utf8'));
}

function writeAssetRecord(fileHash, record) {
  const db = readAssetsDb();
  db[fileHash] = record;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(ASSETS_DB_PATH, JSON.stringify(db, null, 2));
}

function getAssetRecord(fileHash) {
  const db = readAssetsDb();
  return db[fileHash] || null;
}

// ---- Off-chain integrity check log ---------------------------------------
// NOT blockchain-anchored — this is an app-level convenience log so Admin
// and the Audit Log page can see when someone checked a file's integrity
// and what the result was. The actual security guarantee is the hash
// already anchored on-chain at creation; this just records who checked
// what, and when, for operational visibility.

function readIntegrityLog() {
  if (!fs.existsSync(INTEGRITY_LOG_PATH)) return [];
  return JSON.parse(fs.readFileSync(INTEGRITY_LOG_PATH, 'utf8'));
}

function appendIntegrityLog(entry) {
  const log = readIntegrityLog();
  log.push(entry);
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(INTEGRITY_LOG_PATH, JSON.stringify(log, null, 2));
  return entry;
}

// ---- Core crypto steps ---------------------------------------------------

function hashFile(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function signBuffer(buffer, privateKeyPem) {
  const sign = crypto.createSign('SHA256');
  sign.update(buffer);
  sign.end();
  return sign.sign(privateKeyPem, 'hex');
}

function verifyBuffer(buffer, publicKeyPem, signatureHex) {
  const verify = crypto.createVerify('SHA256');
  verify.update(buffer);
  verify.end();
  return verify.verify(publicKeyPem, signatureHex, 'hex');
}

function aesEncrypt(buffer) {
  const aesKey = crypto.randomBytes(32);
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-gcm', aesKey, iv);
  const encrypted = Buffer.concat([cipher.update(buffer), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return { aesKey, iv, encrypted, authTag };
}

function aesDecrypt(encryptedBuffer, aesKey, iv, authTag) {
  const decipher = crypto.createDecipheriv('aes-256-gcm', aesKey, iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(encryptedBuffer), decipher.final()]);
}

function splitKey(aesKey, numShares, threshold) {
  return secrets.split(aesKey, { shares: numShares, threshold });
}

function combineShares(rawShares) {
  return Buffer.from(secrets.combine(rawShares));
}

async function wrapShare(rawShare, custodianPublicKeyHex) {
  const publicKey = Buffer.from(custodianPublicKeyHex, 'hex');
  const wrapped = await eccrypto.encrypt(publicKey, Buffer.from(rawShare));
  return {
    iv: wrapped.iv.toString('hex'),
    ephemPublicKey: wrapped.ephemPublicKey.toString('hex'),
    ciphertext: wrapped.ciphertext.toString('hex'),
    mac: wrapped.mac.toString('hex'),
  };
}

async function unwrapShare(wrapped, custodianPrivateKeyHex) {
  const privateKey = Buffer.from(custodianPrivateKeyHex, 'hex');
  const wrappedObj = {
    iv: Buffer.from(wrapped.iv, 'hex'),
    ephemPublicKey: Buffer.from(wrapped.ephemPublicKey, 'hex'),
    ciphertext: Buffer.from(wrapped.ciphertext, 'hex'),
    mac: Buffer.from(wrapped.mac, 'hex'),
  };
  return eccrypto.decrypt(privateKey, wrappedObj);
}

module.exports = {
  loadOrCreateNtaKeys,
  loadOrCreateCustodians,
  writeAssetRecord,
  getAssetRecord,
  readIntegrityLog,
  appendIntegrityLog,
  hashFile,
  signBuffer,
  verifyBuffer,
  aesEncrypt,
  aesDecrypt,
  splitKey,
  combineShares,
  wrapShare,
  unwrapShare,
};
