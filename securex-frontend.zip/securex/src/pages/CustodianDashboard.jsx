import { useCallback, useEffect, useState } from "react";
import { useContract } from "../hooks/useContract";
import { useRoles } from "../context/RoleContext";
import { AccentButton, EmptyState, ErrorBanner, Pill, Spinner } from "../components/ui";
import { formatDateTime } from "../utils/format";

// The contract doesn't expose a "list all tokenIds" method, so we discover
// them the same way the Audit Log does: from AssetCreated events. This is
// the standard pattern for enumerable on-chain assets without an index.
export default function CustodianDashboard() {
  const { queryAllEvents, getAsset, submitShare } = useContract();
  const { isCustodian, loadingRoles } = useRoles();

  const [rows, setRows] = useState(null); // null = loading
  const [error, setError] = useState(null);
  const [submittingId, setSubmittingId] = useState(null);
  const [refreshTick, setRefreshTick] = useState(0);

  const load = useCallback(async () => {
    setError(null);
    try {
      const events = await queryAllEvents();
      const createdEvents = events.filter((e) => e.eventName === "AssetCreated");
      const tokenIds = [...new Set(createdEvents.map((e) => e.args.tokenId.toString()))];

      const assets = await Promise.all(
        tokenIds.map(async (id) => {
          const asset = await getAsset(id);
          return { tokenId: id, ...asset };
        })
      );

      const pending = assets
        .filter((a) => !a.released && a.sharesSubmitted < a.threshold)
        .sort((a, b) => Number(a.releaseTime) - Number(b.releaseTime));

      setRows(pending);
    } catch (err) {
      setError(err?.message || "Could not load pending assets.");
      setRows([]);
    }
  }, [queryAllEvents, getAsset]);

  useEffect(() => {
    if (isCustodian) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load, refreshTick, isCustodian]);

  async function handleSubmitShare(tokenId) {
    setError(null);
    setSubmittingId(tokenId);
    try {
      await submitShare(tokenId);
      setRefreshTick((t) => t + 1);
    } catch (err) {
      setError(err?.reason || err?.message || `Could not submit share for asset #${tokenId}.`);
    } finally {
      setSubmittingId(null);
    }
  }

  if (loadingRoles) {
    return (
      <div className="flex items-center justify-center gap-2 py-24 text-sm text-ink-faint">
        <Spinner className="h-4 w-4" /> Checking your role…
      </div>
    );
  }

  if (!isCustodian) {
    return (
      <div className="mx-auto max-w-3xl px-6 py-10">
        <EmptyState
          title="You're not a custodian on this contract"
          description="Your connected wallet doesn't hold the CUSTODIAN_ROLE for this SecureX deployment, so there's nothing to submit here. If this seems wrong, ask the admin to grant your address the Custodian role."
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <header className="mb-8">
        <p className="text-sm font-medium text-custodian-600">Custodian</p>
        <h1 className="mt-1 text-2xl font-semibold text-ink">
          Pending share submissions
        </h1>
        <p className="mt-1 text-sm text-ink-soft">
          Assets waiting on your key share before they reach the release
          threshold.
        </p>
      </header>

      <ErrorBanner message={error} />

      {rows === null ? (
        <div className="flex items-center gap-2 py-16 justify-center text-sm text-ink-faint">
          <Spinner className="h-4 w-4" /> Loading assets…
        </div>
      ) : rows.length === 0 ? (
        <EmptyState
          title="Nothing pending"
          description="Every known asset already has enough shares submitted, or none have been created yet."
        />
      ) : (
        <div className="mt-4 overflow-hidden rounded-xl border border-gray-200 shadow-card">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs font-medium uppercase tracking-wide text-ink-faint">
              <tr>
                <th className="px-5 py-3">Token</th>
                <th className="px-5 py-3">Release time</th>
                <th className="px-5 py-3">Shares</th>
                <th className="px-5 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {rows.map((row) => (
                <tr key={row.tokenId}>
                  <td className="px-5 py-4 font-mono text-ink">#{row.tokenId}</td>
                  <td className="px-5 py-4 text-ink-soft">
                    {formatDateTime(row.releaseTime)}
                  </td>
                  <td className="px-5 py-4">
                    <Pill tone="purple">
                      {row.sharesSubmitted.toString()} / {row.threshold.toString()}
                    </Pill>
                  </td>
                  <td className="px-5 py-4 text-right">
                    <AccentButton
                      accent="custodian"
                      onClick={() => handleSubmitShare(row.tokenId)}
                      disabled={submittingId !== null}
                      className="px-3 py-1.5 text-xs"
                    >
                      {submittingId === row.tokenId && <Spinner className="h-3.5 w-3.5" />}
                      Submit My Share
                    </AccentButton>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
