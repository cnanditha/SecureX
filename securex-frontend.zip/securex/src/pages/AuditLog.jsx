import { useCallback, useEffect, useState } from "react";
import { useWeb3 } from "../context/Web3Context";
import { useContract } from "../hooks/useContract";
import { API_BASE_URL } from "../contract.config";
import { EmptyState, ErrorBanner, Pill, Spinner } from "../components/ui";
import { addressUrl, shortAddress, txUrl } from "../utils/format";

const EVENT_META = {
  AssetCreated: { label: "Asset created", tone: "blue" },
  ShareSubmitted: { label: "Share submitted", tone: "purple" },
  DecryptAttempt: { label: "Decrypt attempt", tone: "amber" },
  AssetReleased: { label: "Asset released", tone: "green" },
  IntegrityCheck: { label: "Integrity check", tone: "gray" },
};

export default function AuditLog() {
  const { provider } = useWeb3();
  const { queryAllEvents } = useContract();

  const [events, setEvents] = useState(null);
  const [error, setError] = useState(null);
  const [blockTimestamps, setBlockTimestamps] = useState({});

  const load = useCallback(async () => {
    setError(null);
    try {
      const onChain = await queryAllEvents();

      // Resolve block timestamps for display (deduped).
      const uniqueBlocks = [...new Set(onChain.map((e) => e.blockNumber))];
      const timestamps = {};
      await Promise.all(
        uniqueBlocks.map(async (bn) => {
          try {
            const block = await provider.getBlock(bn);
            timestamps[bn] = block?.timestamp ?? null;
          } catch {
            timestamps[bn] = null;
          }
        })
      );
      setBlockTimestamps(timestamps);

      // Off-chain integrity checks, normalized into the same shape so they
      // can be sorted into one combined timeline. Clearly tagged as
      // off-chain in the UI — these are app-level log entries, not
      // blockchain events, and have no block number or transaction hash.
      let offChain = [];
      try {
        const res = await fetch(`${API_BASE_URL}/integrity-log`);
        if (res.ok) {
          const log = await res.json();
          offChain = log.map((entry, i) => ({
            eventName: "IntegrityCheck",
            source: "offchain",
            args: entry,
            blockNumber: null,
            transactionHash: null,
            logIndex: i,
            timestampMs: entry.timestamp,
          }));
        }
      } catch {
        // non-fatal — audit log still shows the on-chain events
      }

      const onChainNormalized = onChain.map((e) => ({
        ...e,
        source: "chain",
        timestampMs: timestamps[e.blockNumber] ? timestamps[e.blockNumber] * 1000 : 0,
      }));

      const combined = [...onChainNormalized, ...offChain].sort(
        (a, b) => b.timestampMs - a.timestampMs
      );
      setEvents(combined);
    } catch (err) {
      setError(err?.message || "Could not load the audit log.");
      setEvents([]);
    }
  }, [queryAllEvents, provider]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <header className="mb-8">
        <p className="text-sm font-medium text-ink-soft">Audit Log</p>
        <h1 className="mt-1 text-2xl font-semibold text-ink">
          Complete event timeline
        </h1>
        <p className="mt-1 text-sm text-ink-soft">
          On-chain events (asset creation, share submissions, release
          attempts) plus off-chain integrity checks, in chronological order.
        </p>
      </header>

      <ErrorBanner message={error} />

      {events === null ? (
        <div className="flex items-center gap-2 py-16 justify-center text-sm text-ink-faint">
          <Spinner className="h-4 w-4" /> Loading events…
        </div>
      ) : events.length === 0 ? (
        <EmptyState
          title="No events yet"
          description="Once assets are created on-chain, activity will appear here."
        />
      ) : (
        <ol className="relative border-l border-gray-200 pl-6">
          {events.map((event, i) => (
            <li
              key={
                event.source === "chain"
                  ? `${event.transactionHash}-${event.logIndex}`
                  : `offchain-${event.args.timestamp}-${i}`
              }
              className="mb-8 last:mb-0"
            >
              <span
                className={`absolute -left-[5px] mt-1.5 h-2.5 w-2.5 rounded-full border-2 border-white ${
                  event.source === "offchain" ? "bg-public-600" : "bg-gray-300"
                }`}
              />
              <EventCard
                event={event}
                timestamp={
                  event.source === "chain"
                    ? blockTimestamps[event.blockNumber]
                    : Math.floor(event.timestampMs / 1000)
                }
              />
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

function EventCard({ event, timestamp }) {
  const meta = EVENT_META[event.eventName] ?? { label: event.eventName, tone: "gray" };

  return (
    <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-card">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Pill tone={meta.tone}>{meta.label}</Pill>
          {event.source === "offchain" && (
            <span className="text-xs font-medium text-public-600">
              off-chain
            </span>
          )}
        </div>
        <span className="text-xs text-ink-faint">
          {event.source === "chain" && `Block #${event.blockNumber} · `}
          {timestamp ? new Date(timestamp * 1000).toLocaleString() : ""}
        </span>
      </div>

      <div className="mt-3 space-y-1.5 text-sm">
        <EventBody event={event} />
      </div>

      {event.source === "chain" && (
        <a
          href={txUrl(event.transactionHash)}
          target="_blank"
          rel="noreferrer"
          className="mt-3 inline-block font-mono text-xs text-ink-faint hover:text-ink-soft"
        >
          {shortAddress(event.transactionHash, 6)} ↗
        </a>
      )}
    </div>
  );
}

function EventBody({ event }) {
  const { eventName, args } = event;

  if (eventName === "AssetCreated") {
    return (
      <>
        <Field label="Token ID" value={args.tokenId.toString()} />
        <Field label="File hash" value={args.fileHash} mono />
        <Field
          label="Release time"
          value={new Date(Number(args.releaseTime) * 1000).toLocaleString()}
        />
      </>
    );
  }

  if (eventName === "ShareSubmitted") {
    return (
      <>
        <Field label="Token ID" value={args.tokenId.toString()} />
        <Field label="Custodian" value={args.custodian} link={addressUrl(args.custodian)} />
        <Field label="Total shares so far" value={args.totalSoFar.toString()} />
      </>
    );
  }

  if (eventName === "DecryptAttempt") {
    return (
      <>
        <Field label="Token ID" value={args.tokenId.toString()} />
        <Field label="Caller" value={args.caller} link={addressUrl(args.caller)} />
        <Field
          label="Result"
          value={args.success ? "Success" : `Failed — ${args.reason || "no reason given"}`}
        />
      </>
    );
  }

  if (eventName === "AssetReleased") {
    return (
      <>
        <Field label="Token ID" value={args.tokenId.toString()} />
        <Field label="Released to" value={args.to} link={addressUrl(args.to)} />
      </>
    );
  }

  if (eventName === "IntegrityCheck") {
    return (
      <>
        <Field label="Token ID" value={args.tokenId} />
        <Field
          label="Checked by"
          value={args.checkerAddress || "unknown"}
          link={args.checkerAddress ? addressUrl(args.checkerAddress) : undefined}
        />
        <Field
          label="Result"
          value={args.matched ? "Match" : "Mismatch — file has been altered"}
        />
      </>
    );
  }

  return null;
}

function Field({ label, value, mono, link }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <span className="flex-none text-ink-faint">{label}</span>
      {link ? (
        <a
          href={link}
          target="_blank"
          rel="noreferrer"
          className={`text-right text-admin-600 hover:text-admin-700 ${mono ? "font-mono text-xs" : ""} break-all`}
        >
          {value}
        </a>
      ) : (
        <span className={`text-right text-ink ${mono ? "font-mono text-xs" : ""} break-all`}>
          {value}
        </span>
      )}
    </div>
  );
}
