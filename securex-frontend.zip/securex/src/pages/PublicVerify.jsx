import { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { useContract } from "../hooks/useContract";
import { CONTRACT_ADDRESS } from "../contract.config";
import { AccentButton, ErrorBanner, Pill, Spinner } from "../components/ui";
import Card from "../components/Card";
import { addressUrl, formatDateTime } from "../utils/format";

// This page is deliberately read-only: no submitShare, no attemptRelease,
// no decrypt. Anyone — custodian, admin, or a completely unaffiliated
// wallet — can look up an asset here and confirm what's actually recorded
// on-chain, without needing any role at all.
export default function PublicVerify() {
  const { getAsset } = useContract();
  const [searchParams, setSearchParams] = useSearchParams();

  const [tokenIdInput, setTokenIdInput] = useState(searchParams.get("tokenId") || "");
  const [tokenId, setTokenId] = useState(searchParams.get("tokenId") || null);
  const [asset, setAsset] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!tokenId) return;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const a = await getAsset(tokenId);
        setAsset(a);
      } catch (err) {
        setAsset(null);
        setError(err?.message || `Could not find asset #${tokenId}.`);
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tokenId]);

  function handleLookup(e) {
    e.preventDefault();
    if (!tokenIdInput) return;
    setTokenId(tokenIdInput);
    setSearchParams({ tokenId: tokenIdInput });
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <header className="mb-8">
        <p className="text-sm font-medium text-public-600">Public</p>
        <h1 className="mt-1 text-2xl font-semibold text-ink">
          Independently verify an asset
        </h1>
        <p className="mt-1 text-sm text-ink-soft">
          No special role is required to see this. Everything below is read
          directly from the SecureX contract on Ethereum Sepolia — you don't
          have to trust this app; you can confirm every field yourself on{" "}
          <a
            href={addressUrl(CONTRACT_ADDRESS)}
            target="_blank"
            rel="noreferrer"
            className="font-medium text-public-600 hover:text-public-700"
          >
            Sepolia Etherscan
          </a>
          .
        </p>
      </header>

      <form onSubmit={handleLookup} className="flex gap-3">
        <input
          type="number"
          min={0}
          placeholder="Token ID, e.g. 4"
          value={tokenIdInput}
          onChange={(e) => setTokenIdInput(e.target.value)}
          className="w-full max-w-xs rounded-md border border-gray-300 px-3 py-2 text-sm text-ink focus:border-public-600 focus:outline-none focus:ring-1 focus:ring-public-600"
        />
        <AccentButton accent="public" type="submit" disabled={!tokenIdInput}>
          Look up
        </AccentButton>
      </form>

      <ErrorBanner message={error} />

      {loading && (
        <div className="mt-8 flex items-center gap-2 text-sm text-ink-faint">
          <Spinner className="h-4 w-4" /> Loading asset…
        </div>
      )}

      {asset && !loading && (
        <Card accent="public" className="mt-8">
          <div className="flex items-start justify-between">
            <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">
              Asset #{tokenId}
            </p>
            <Pill tone={asset.released ? "green" : "amber"}>
              {asset.released ? "Released" : "Locked"}
            </Pill>
          </div>

          <dl className="mt-4 space-y-3 text-sm">
            <Row label="File hash (SHA-256)" value={asset.fileHash} mono />
            <Row label="NTA signature (ECDSA)" value={asset.signature} mono truncate />
            <Row label="IPFS CID" value={asset.ipfsCID} mono />
            <Row label="Release time" value={formatDateTime(asset.releaseTime)} />
            <Row
              label="Custodian shares"
              value={`${asset.sharesSubmitted.toString()} / ${asset.threshold.toString()} submitted`}
            />
          </dl>

          <p className="mt-6 text-xs text-ink-faint">
            To verify the hash yourself: download the same paper, compute its
            SHA-256, and compare it to the value above — a single differing
            character means the file has been altered since creation.
          </p>
        </Card>
      )}

      <div className="mt-10 rounded-xl border border-dashed border-gray-300 px-6 py-6 text-center">
        <p className="text-sm text-ink-soft">
          Want the full history — every share submission and every rejected
          attempt, not just one asset?
        </p>
        <Link
          to="/audit-log"
          className="mt-2 inline-block text-sm font-medium text-public-600 hover:text-public-700"
        >
          View the complete on-chain audit log →
        </Link>
      </div>
    </div>
  );
}

function Row({ label, value, mono, truncate }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <dt className="flex-none text-ink-faint">{label}</dt>
      <dd
        className={`text-right text-ink ${mono ? "font-mono text-xs" : ""} ${
          truncate ? "max-w-xs truncate" : "break-all"
        }`}
      >
        {value}
      </dd>
    </div>
  );
}
