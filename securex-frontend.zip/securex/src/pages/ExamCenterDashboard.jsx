import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useWeb3 } from "../context/Web3Context";
import { useContract } from "../hooks/useContract";
import { API_BASE_URL } from "../contract.config";
import { AccentButton, ErrorBanner, Pill, Spinner } from "../components/ui";
import Card from "../components/Card";
import { formatDateTime, secondsToCountdown } from "../utils/format";
import { sha256HexOfFile } from "../utils/hash";

export default function ExamCenterDashboard() {
  const { address } = useWeb3();
  const { getAsset, attemptRelease } = useContract();
  const [searchParams, setSearchParams] = useSearchParams();

  const [tokenIdInput, setTokenIdInput] = useState(searchParams.get("tokenId") || "");
  const [tokenId, setTokenId] = useState(searchParams.get("tokenId") || null);

  const [asset, setAsset] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [now, setNow] = useState(Date.now());

  const [releasing, setReleasing] = useState(false);
  const [releaseError, setReleaseError] = useState(null);

  const [verifying, setVerifying] = useState(false);
  const [verifyError, setVerifyError] = useState(null);
  const [verification, setVerification] = useState(null); // { hashMatch, signatureValid, downloadUrl }

  const [integrityFile, setIntegrityFile] = useState(null);
  const [checkingIntegrity, setCheckingIntegrity] = useState(false);
  const [integrityError, setIntegrityError] = useState(null);
  const [integrityResult, setIntegrityResult] = useState(null); // { computedHash, recordedHash, matched }

  // Live clock for the countdown.
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  async function loadAsset(id) {
    setLoading(true);
    setError(null);
    setVerification(null);
    setIntegrityResult(null);
    setIntegrityFile(null);
    try {
      const a = await getAsset(id);
      setAsset(a);
    } catch (err) {
      setAsset(null);
      setError(err?.message || `Could not find asset #${id}.`);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (tokenId) loadAsset(tokenId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tokenId]);

  function handleLookup(e) {
    e.preventDefault();
    if (!tokenIdInput) return;
    setTokenId(tokenIdInput);
    setSearchParams({ tokenId: tokenIdInput });
  }

  const secondsRemaining = useMemo(() => {
    if (!asset) return null;
    const releaseMs = Number(asset.releaseTime) * 1000;
    return Math.max(0, Math.floor((releaseMs - now) / 1000));
  }, [asset, now]);

  const releaseTimeReached = secondsRemaining === 0;

  async function handleAttemptRelease() {
    setReleaseError(null);
    setReleasing(true);
    try {
      const { success, reason } = await attemptRelease(tokenId, address);
      if (!success) {
        // The transaction was mined, but the contract's own checks
        // (time-lock or share threshold) rejected the release — this is
        // NOT a wallet/network error, it's the mechanism working correctly.
        setReleaseError(
          reason === "Too early"
            ? "Rejected on-chain: release time has not been reached yet."
            : reason === "Not enough shares"
            ? "Rejected on-chain: not enough custodian shares submitted yet."
            : reason || "Release was not approved by the contract."
        );
      }
      await loadAsset(tokenId);
    } catch (err) {
      setReleaseError(err?.reason || err?.message || "Release attempt failed.");
    } finally {
      setReleasing(false);
    }
  }

  async function handleDecryptVerify() {
    setVerifyError(null);
    setVerifying(true);
    setVerification(null);
    try {
      const res = await fetch(`${API_BASE_URL}/decrypt-asset`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tokenId, requesterAddress: address }),
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(text || `Decrypt request failed (HTTP ${res.status}).`);
      }
      const data = await res.json();
      // Expected shape: { hashMatch: bool, signatureValid: bool, downloadUrl?: string }
      setVerification(data);
    } catch (err) {
      setVerifyError(err?.message || "Could not decrypt and verify the asset.");
    } finally {
      setVerifying(false);
    }
  }

  async function handleCheckIntegrity() {
    setIntegrityError(null);
    setIntegrityResult(null);
    setCheckingIntegrity(true);
    try {
      // Hashing happens right here in the browser — the file never leaves
      // this device just to be checked.
      const computedHash = await sha256HexOfFile(integrityFile);
      const recordedHash = asset.fileHash;
      const matched = computedHash === recordedHash;
      setIntegrityResult({ computedHash, recordedHash, matched });

      // Log the result so Admin and the Audit Log page can see it too.
      // This log is off-chain / app-level — the actual tamper-evidence
      // guarantee is the hash already anchored on-chain at creation.
      fetch(`${API_BASE_URL}/integrity-log`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tokenId,
          checkerAddress: address,
          computedHash,
          recordedHash,
          matched,
        }),
      }).catch(() => {
        // Non-fatal: the check itself already succeeded and is shown
        // below even if logging it fails (e.g. backend unreachable).
      });
    } catch (err) {
      setIntegrityError(err?.message || "Could not hash the selected file.");
    } finally {
      setCheckingIntegrity(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <header className="mb-8">
        <p className="text-sm font-medium text-exam-600">Exam Center</p>
        <h1 className="mt-1 text-2xl font-semibold text-ink">
          Track and release an exam asset
        </h1>
        <p className="mt-1 text-sm text-ink-soft">
          Look up an asset by token ID to see its release countdown and
          custodian share progress.
        </p>
      </header>

      <form onSubmit={handleLookup} className="flex gap-3">
        <input
          type="number"
          min={0}
          placeholder="Token ID, e.g. 4"
          value={tokenIdInput}
          onChange={(e) => setTokenIdInput(e.target.value)}
          className="w-full max-w-xs rounded-md border border-gray-300 px-3 py-2 text-sm text-ink focus:border-exam-600 focus:outline-none focus:ring-1 focus:ring-exam-600"
        />
        <AccentButton accent="exam" type="submit" disabled={!tokenIdInput}>
          Look up
        </AccentButton>
      </form>

      <ErrorBanner message={error} />

      {loading && (
        <div className="mt-8 flex items-center gap-2 text-sm text-ink-faint">
          <Spinner className="h-4 w-4" /> Loading asset…
        </div>
      )}

      {asset && !loading && (
        <div className="mt-8 space-y-6">
          <Card accent="exam">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-faint">
                  Asset #{tokenId}
                </p>
                <p className="mt-1 font-mono text-xs text-ink-soft break-all">
                  {asset.fileHash}
                </p>
              </div>
              <Pill tone={asset.released ? "green" : "amber"}>
                {asset.released ? "Released" : "Locked"}
              </Pill>
            </div>

            <div className="mt-6 grid gap-6 sm:grid-cols-2">
              <div>
                <p className="text-xs text-ink-faint">Release time</p>
                <p className="mt-1 text-sm text-ink">
                  {formatDateTime(asset.releaseTime)}
                </p>
              </div>
              <div>
                <p className="text-xs text-ink-faint">Custodian shares</p>
                <p className="mt-1 text-sm text-ink">
                  {asset.sharesSubmitted.toString()} / {asset.threshold.toString()}{" "}
                  submitted
                </p>
              </div>
            </div>

            {!asset.released && (
              <div className="mt-6 rounded-lg bg-gray-50 px-5 py-4 text-center">
                <p className="text-xs uppercase tracking-wide text-ink-faint">
                  {releaseTimeReached ? "Release time reached" : "Time until release"}
                </p>
                <p className="mt-1 font-mono text-2xl tabular text-ink">
                  {secondsToCountdown(secondsRemaining ?? 0)}
                </p>
              </div>
            )}

            {!asset.released && (
              <div className="mt-6">
                <ErrorBanner message={releaseError} />
                <AccentButton
                  accent="exam"
                  onClick={handleAttemptRelease}
                  disabled={releasing || !releaseTimeReached}
                  className="mt-3 w-full"
                >
                  {releasing && <Spinner />}
                  {releasing ? "Confirm in wallet…" : "Attempt Release"}
                </AccentButton>
                {!releaseTimeReached && (
                  <p className="mt-2 text-center text-xs text-ink-faint">
                    Available once the countdown reaches zero and the share
                    threshold is met.
                  </p>
                )}
              </div>
            )}
          </Card>

          <Card accent="exam">
            <h2 className="text-sm font-semibold text-ink">
              Verify file integrity
            </h2>
            <p className="mt-1 text-sm text-ink-soft">
              Check any copy of the paper — a printed-and-rescanned file, one
              received through another channel, anything — against the hash
              sealed on-chain at creation. Hashing happens in your browser;
              the file itself is never uploaded anywhere.
            </p>

            <input
              type="file"
              onChange={(e) => {
                setIntegrityFile(e.target.files?.[0] ?? null);
                setIntegrityResult(null);
                setIntegrityError(null);
              }}
              className="mt-4 block w-full text-sm text-ink-soft file:mr-4 file:rounded-md file:border-0 file:bg-exam-50 file:px-4 file:py-2 file:text-sm file:font-medium file:text-exam-700 hover:file:bg-exam-100"
            />

            <ErrorBanner message={integrityError} />

            <AccentButton
              accent="exam"
              onClick={handleCheckIntegrity}
              disabled={!integrityFile || checkingIntegrity}
              className="mt-4"
            >
              {checkingIntegrity && <Spinner />}
              {checkingIntegrity ? "Hashing…" : "Check Integrity"}
            </AccentButton>

            {integrityResult && (
              <div className="mt-6 space-y-3">
                <div
                  className={`rounded-lg px-4 py-3 text-sm font-medium ${
                    integrityResult.matched
                      ? "bg-emerald-50 text-emerald-700"
                      : "bg-red-50 text-red-700"
                  }`}
                >
                  {integrityResult.matched
                    ? "✅ Match — this file is exactly what was sealed at creation."
                    : "❌ Mismatch — this file has been altered since creation."}
                </div>
                <div className="rounded-md border border-gray-200 px-4 py-3 text-xs">
                  <p className="flex justify-between gap-4">
                    <span className="text-ink-faint">Recorded on-chain</span>
                    <span className="font-mono text-ink break-all text-right">
                      {integrityResult.recordedHash}
                    </span>
                  </p>
                  <p className="mt-2 flex justify-between gap-4">
                    <span className="text-ink-faint">Computed just now</span>
                    <span className="font-mono text-ink break-all text-right">
                      {integrityResult.computedHash}
                    </span>
                  </p>
                </div>
                <p className="text-xs text-ink-faint">
                  This result has been logged and is visible on the Admin
                  dashboard and the Audit Log.
                </p>
              </div>
            )}
          </Card>

          {asset.released && (
            <Card accent="exam">
              <h2 className="text-sm font-semibold text-ink">Decrypt &amp; verify</h2>
              <p className="mt-1 text-sm text-ink-soft">
                Reconstructs the key from submitted shares, downloads the
                encrypted file from IPFS, decrypts it, and checks the hash and
                signature against what was anchored on-chain.
              </p>

              <ErrorBanner message={verifyError} />

              <AccentButton
                accent="exam"
                onClick={handleDecryptVerify}
                disabled={verifying}
                className="mt-4"
              >
                {verifying && <Spinner />}
                {verifying ? "Verifying…" : "Decrypt & Verify"}
              </AccentButton>

              {verification && (
                <div className="mt-6 space-y-3">
                  <VerificationRow
                    label="File hash matches"
                    passed={verification.hashMatch}
                  />
                  <VerificationRow
                    label="Signature valid"
                    passed={verification.signatureValid}
                  />

                  {verification.hashMatch && verification.signatureValid && verification.downloadUrl && (
                    <a
                      href={verification.downloadUrl}
                      className="mt-4 inline-flex items-center gap-2 rounded-md bg-exam-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-exam-700"
                    >
                      Download decrypted file
                    </a>
                  )}

                  {(!verification.hashMatch || !verification.signatureValid) && (
                    <p className="text-sm text-red-700">
                      Verification failed — do not use this file. Report this
                      asset for investigation.
                    </p>
                  )}
                </div>
              )}
            </Card>
          )}
        </div>
      )}
    </div>
  );
}

function VerificationRow({ label, passed }) {
  return (
    <div className="flex items-center justify-between rounded-md border border-gray-200 px-4 py-3">
      <span className="text-sm text-ink">{label}</span>
      {passed ? (
        <span className="flex items-center gap-1.5 text-sm font-medium text-emerald-600">
          <CheckIcon /> Passed
        </span>
      ) : (
        <span className="flex items-center gap-1.5 text-sm font-medium text-red-600">
          <XIcon /> Failed
        </span>
      )}
    </div>
  );
}

function CheckIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
      <path
        fillRule="evenodd"
        d="M16.7 5.3a1 1 0 010 1.4l-7.4 7.4a1 1 0 01-1.4 0L3.3 9.5a1 1 0 111.4-1.4l3.9 3.9 6.7-6.7a1 1 0 011.4 0z"
        clipRule="evenodd"
      />
    </svg>
  );
}

function XIcon() {
  return (
    <svg className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
      <path
        fillRule="evenodd"
        d="M4.3 4.3a1 1 0 011.4 0L10 8.6l4.3-4.3a1 1 0 111.4 1.4L11.4 10l4.3 4.3a1 1 0 01-1.4 1.4L10 11.4l-4.3 4.3a1 1 0 01-1.4-1.4L8.6 10 4.3 5.7a1 1 0 010-1.4z"
        clipRule="evenodd"
      />
    </svg>
  );
}
