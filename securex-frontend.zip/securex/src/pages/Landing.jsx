import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useWeb3 } from "../context/Web3Context";
import { useRoles } from "../context/RoleContext";
import { AccentButton, ErrorBanner, Spinner } from "../components/ui";
import Card from "../components/Card";

export default function Landing() {
  const { address, hasWallet, connecting, error, connect, isSepolia } = useWeb3();
  const { isAdmin, isCustodian, isExamCenter, loadingRoles, roleError } = useRoles();
  const navigate = useNavigate();
  const [redirecting, setRedirecting] = useState(false);

  useEffect(() => {
    if (!address || !isSepolia || loadingRoles) return;
    setRedirecting(true);
    if (isAdmin) navigate("/admin", { replace: true });
    else if (isCustodian) navigate("/custodian", { replace: true });
    else if (isExamCenter) navigate("/exam-center", { replace: true });
    else navigate("/verify", { replace: true });
  }, [address, isSepolia, loadingRoles, isAdmin, isCustodian, isExamCenter, navigate]);

  return (
    <div className="mx-auto flex min-h-[calc(100vh-56px)] max-w-6xl items-center px-6">
      <div className="grid w-full items-center gap-16 lg:grid-cols-2">
        <div>
          <p className="text-sm font-medium text-admin-600">
            Chain of custody for exam papers
          </p>
          <h1 className="mt-3 text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
            SecureX
          </h1>
          <p className="mt-4 max-w-md text-base leading-relaxed text-ink-soft">
            Every paper is hashed, signed, encrypted, and split across
            custodians before it ever reaches a print room. Nothing unlocks
            before the release time, and every step is recorded on Sepolia.
          </p>

          <div className="mt-8 space-y-3">
            {!hasWallet && (
              <ErrorBanner message="No wallet detected. Install MetaMask to connect." />
            )}
            <ErrorBanner message={error} />
            <ErrorBanner message={roleError} />

            {!address ? (
              <AccentButton
                accent="admin"
                onClick={connect}
                disabled={connecting || !hasWallet}
                className="px-6 py-3 text-base"
              >
                {connecting && <Spinner />}
                {connecting ? "Connecting…" : "Connect MetaMask"}
              </AccentButton>
            ) : !isSepolia ? (
              <p className="text-sm text-amber-700">
                Wallet connected — switch to Sepolia using the banner above to
                continue.
              </p>
            ) : (
              <div className="flex items-center gap-2 text-sm text-ink-soft">
                <Spinner className="h-4 w-4 text-ink-faint" />
                {loadingRoles || !redirecting ? "Checking your role…" : "Redirecting…"}
              </div>
            )}
          </div>
        </div>

        <div className="grid gap-4">
          <RoleCard
            accent="admin"
            title="Exam Board / Admin"
            description="Upload papers, set release windows, and create the on-chain asset that anchors the chain of custody."
          />
          <RoleCard
            accent="custodian"
            title="Custodian"
            description="Hold one key share of an asset and submit it toward the threshold needed to unlock release."
          />
          <RoleCard
            accent="exam"
            title="Exam Center"
            description="Track the countdown to release, attempt release at the print location, then decrypt and verify."
          />
          <RoleCard
            accent="public"
            title="Public"
            description="Anyone with a wallet — no special role needed — can independently verify an asset's hash, signature, and full on-chain history."
          />
        </div>
      </div>
    </div>
  );
}

const ACCENT_DOT = {
  admin: "bg-admin-600",
  custodian: "bg-custodian-600",
  exam: "bg-exam-600",
  public: "bg-public-600",
};

function RoleCard({ accent, title, description }) {
  return (
    <Card accent={accent}>
      <div className="flex items-start gap-3">
        <span className={`mt-1.5 h-2 w-2 flex-none rounded-full ${ACCENT_DOT[accent]}`} />
        <div>
          <h3 className="text-sm font-semibold text-ink">{title}</h3>
          <p className="mt-1 text-sm leading-relaxed text-ink-soft">
            {description}
          </p>
        </div>
      </div>
    </Card>
  );
}
