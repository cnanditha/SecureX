import { useCallback, useEffect, useState } from "react";
import { useWeb3 } from "../context/Web3Context";
import { useContract } from "../hooks/useContract";
import { API_BASE_URL } from "../contract.config";
import { AccentButton, ErrorBanner, Pill, Spinner, EmptyState } from "../components/ui";
import Card from "../components/Card";
import { toUnixSeconds, txUrl, formatDateTime } from "../utils/format";

export default function AdminDashboard() {
  const { address } = useWeb3();
  const { createAsset, queryAllEvents, getAsset } = useContract();

  const [file, setFile] = useState(null);
  const [releaseTimeLocal, setReleaseTimeLocal] = useState("");
  const [threshold, setThreshold] = useState(2);

  const [stage, setStage] = useState("idle"); // idle | preparing | confirming | done
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null); // { hash, signature, cid, tokenId, txHash }

  const [overview, setOverview] = useState(null); // null = loading
  const [overviewError, setOverviewError] = useState(null);
  const [rejectedAttempts, setRejectedAttempts] = useState([]);
  const [failedIntegrityChecks, setFailedIntegrityChecks] = useState([]);
  const [refreshTick, setRefreshTick] = useState(0);

  const canSubmit =
    file && releaseTimeLocal && threshold > 0 && stage === "idle";

  const loadOverview = useCallback(async () => {
    setOverviewError(null);
    try {
      const events = await queryAllEvents();

      const createdEvents = events.filter((e) => e.eventName === "AssetCreated");
      const tokenIds = [...new Set(createdEvents.map((e) => e.args.tokenId.toString()))];
      const assets = await Promise.all(
        tokenIds.map(async (id) => {
          const asset = await getAsset(id);
          return { tokenId: id, ...asset };
        })
      );
      assets.sort((a, b) => Number(a.tokenId) - Number(b.tokenId));
      setOverview(assets);

      const rejected = events
        .filter((e) => e.eventName === "DecryptAttempt" && e.args.success === false)
        .map((e) => ({
          tokenId: e.args.tokenId.toString(),
          caller: e.args.caller,
          reason: e.args.reason,
          txHash: e.transactionHash,
          blockNumber: e.blockNumber,
        }))
        .sort((a, b) => b.blockNumber - a.blockNumber);
      setRejectedAttempts(rejected);
    } catch (err) {
      setOverviewError(err?.message || "Could not load asset overview.");
      setOverview([]);
    }

    // Off-chain integrity check log — separate try/catch so a backend
    // hiccup here doesn't blank out the on-chain data above.
    try {
      const res = await fetch(`${API_BASE_URL}/integrity-log`);
      if (res.ok) {
        const log = await res.json();
        setFailedIntegrityChecks(
          log.filter((e) => !e.matched).sort((a, b) => b.timestamp - a.timestamp)
        );
      }
    } catch {
      // non-fatal — integrity log is a convenience feature, not core data
    }
  }, [queryAllEvents, getAsset]);

  useEffect(() => {
    loadOverview();
  }, [loadOverview, refreshTick]);

  function assetPhase(asset) {
    const nowSec = Math.floor(Date.now() / 1000);
    if (asset.released) return { label: "Released", tone: "green" };
    if (Number(asset.releaseTime) > nowSec) return { label: "Time-locked", tone: "amber" };
    if (Number(asset.sharesSubmitted) < Number(asset.threshold))
      return { label: "Awaiting shares", tone: "amber" };
    return { label: "Ready to release", tone: "blue" };
  }

  async function handleCreateAsset(e) {
    e.preventDefault();
    setError(null);
    setResult(null);

    try {
      // Step 1 — backend does hashing, signing, AES + Shamir + ECC wrap, IPFS upload.
      setStage("preparing");
      const formData = new FormData();
      formData.append("file", file);
      formData.append("releaseTime", toUnixSeconds(releaseTimeLocal).toString());
      formData.append("threshold", String(threshold));
      formData.append("adminAddress", address);

      const res = await fetch(`${API_BASE_URL}/create-asset`, {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(text || `Backend prep failed (HTTP ${res.status}).`);
      }
      const { hash, signature, cid } = await res.json();

      // Step 2 — write the anchor on-chain, from the connected admin wallet.
      setStage("confirming");
      const releaseTime = toUnixSeconds(releaseTimeLocal);
      const { tokenId, txHash } = await createAsset({
        hash,
        signature,
        cid,
        releaseTime,
        threshold: BigInt(threshold),
      });

      setResult({ hash, signature, cid, tokenId, txHash });
      setStage("done");
      setRefreshTick((t) => t + 1);
    } catch (err) {
      setError(err?.reason || err?.message || "Could not create the asset.");
      setStage("idle");
    }
  }

  function resetForm() {
    setFile(null);
    setReleaseTimeLocal("");
    setThreshold(2);
    setResult(null);
    setStage("idle");
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-10">
      <header className="mb-8">
        <p className="text-sm font-medium text-admin-600">Admin</p>
        <h1 className="mt-1 text-2xl font-semibold text-ink">
          Create a secured exam asset
        </h1>
        <p className="mt-1 text-sm text-ink-soft">
          Upload the paper, set when it may be released, and how many
          custodian shares are required. The backend prepares the encrypted
          package; you sign the on-chain anchor from your wallet.
        </p>
      </header>

      <Card accent="admin">
        <form onSubmit={handleCreateAsset} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-ink">
              Exam paper file
            </label>
            <input
              type="file"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
              disabled={stage !== "idle"}
              className="mt-2 block w-full text-sm text-ink-soft file:mr-4 file:rounded-md file:border-0 file:bg-admin-50 file:px-4 file:py-2 file:text-sm file:font-medium file:text-admin-700 hover:file:bg-admin-100"
            />
            {file && (
              <p className="mt-1.5 text-xs text-ink-faint">
                {file.name} · {(file.size / 1024).toFixed(1)} KB
              </p>
            )}
          </div>

          <div className="grid gap-6 sm:grid-cols-2">
            <div>
              <label className="block text-sm font-medium text-ink">
                Release time
              </label>
              <input
                type="datetime-local"
                value={releaseTimeLocal}
                onChange={(e) => setReleaseTimeLocal(e.target.value)}
                disabled={stage !== "idle"}
                className="mt-2 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm text-ink focus:border-admin-600 focus:outline-none focus:ring-1 focus:ring-admin-600"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-ink">
                Share threshold
              </label>
              <input
                type="number"
                min={1}
                value={threshold}
                onChange={(e) => setThreshold(Number(e.target.value))}
                disabled={stage !== "idle"}
                className="mt-2 block w-full rounded-md border border-gray-300 px-3 py-2 text-sm text-ink focus:border-admin-600 focus:outline-none focus:ring-1 focus:ring-admin-600"
              />
              <p className="mt-1.5 text-xs text-ink-faint">
                Number of custodian shares required before release.
              </p>
            </div>
          </div>

          <ErrorBanner message={error} />

          <div className="flex items-center gap-3">
            <AccentButton accent="admin" type="submit" disabled={!canSubmit}>
              {(stage === "preparing" || stage === "confirming") && <Spinner />}
              {stage === "preparing" && "Preparing package…"}
              {stage === "confirming" && "Confirm in wallet…"}
              {stage === "idle" && "Create Asset"}
              {stage === "done" && "Create Asset"}
            </AccentButton>
            {stage === "done" && (
              <button
                type="button"
                onClick={resetForm}
                className="text-sm font-medium text-ink-soft hover:text-ink"
              >
                Create another
              </button>
            )}
          </div>
        </form>
      </Card>

      {result && (
        <Card className="mt-6" accent="admin">
          <h2 className="text-sm font-semibold text-ink">Asset created</h2>
          <dl className="mt-4 space-y-3 text-sm">
            <Row label="Token ID" value={result.tokenId?.toString() ?? "—"} />
            <Row label="File hash" value={result.hash} mono />
            <Row label="Signature" value={result.signature} mono truncate />
            <Row label="IPFS CID" value={result.cid} mono />
          </dl>
          <a
            href={txUrl(result.txHash)}
            target="_blank"
            rel="noreferrer"
            className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-admin-600 hover:text-admin-700"
          >
            View transaction on Sepolia Etherscan
            <span aria-hidden>↗</span>
          </a>
        </Card>
      )}

      {rejectedAttempts.length > 0 && (
        <Card className="mt-6 border-l-4 border-l-red-400" accent={undefined}>
          <h2 className="flex items-center gap-2 text-sm font-semibold text-red-700">
            <span aria-hidden>⚠</span> Rejected release attempts
          </h2>
          <p className="mt-1 text-xs text-ink-faint">
            Someone tried to release an asset before its time-lock passed or
            before enough shares were submitted. Nothing was released — this
            is the system working correctly — but worth reviewing.
          </p>
          <ul className="mt-4 space-y-2">
            {rejectedAttempts.map((r, i) => (
              <li
                key={`${r.txHash}-${i}`}
                className="flex items-center justify-between rounded-md bg-red-50 px-4 py-2.5 text-sm"
              >
                <span className="text-red-800">
                  Asset #{r.tokenId} — <span className="font-medium">{r.reason}</span>
                </span>
                <a
                  href={txUrl(r.txHash)}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-medium text-red-600 hover:text-red-800"
                >
                  View tx ↗
                </a>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {failedIntegrityChecks.length > 0 && (
        <Card className="mt-6 border-l-4 border-l-red-400" accent={undefined}>
          <h2 className="flex items-center gap-2 text-sm font-semibold text-red-700">
            <span aria-hidden>⚠</span> Integrity check failures
          </h2>
          <p className="mt-1 text-xs text-ink-faint">
            Someone checked a file against an asset's on-chain hash and it
            didn't match — meaning that specific copy of the file has been
            altered since creation. This log is app-level, not
            blockchain-anchored; the actual tamper-evidence guarantee is the
            hash already sealed on-chain at creation.
          </p>
          <ul className="mt-4 space-y-2">
            {failedIntegrityChecks.map((c, i) => (
              <li
                key={`${c.tokenId}-${c.timestamp}-${i}`}
                className="rounded-md bg-red-50 px-4 py-2.5 text-sm text-red-800"
              >
                <div className="flex items-center justify-between">
                  <span>
                    Asset #{c.tokenId} — checked by{" "}
                    <span className="font-mono text-xs">
                      {c.checkerAddress || "unknown"}
                    </span>
                  </span>
                  <span className="text-xs text-red-600">
                    {new Date(c.timestamp).toLocaleString()}
                  </span>
                </div>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <div className="mt-10">
        <h2 className="text-sm font-semibold text-ink">All assets</h2>
        <p className="mt-1 text-sm text-ink-soft">
          Current phase of every asset created on this contract.
        </p>

        <ErrorBanner message={overviewError} />

        {overview === null ? (
          <div className="flex items-center gap-2 py-10 justify-center text-sm text-ink-faint">
            <Spinner className="h-4 w-4" /> Loading assets…
          </div>
        ) : overview.length === 0 ? (
          <EmptyState
            title="No assets yet"
            description="Once you create an asset above, it will show up here with its live status."
          />
        ) : (
          <div className="mt-4 overflow-hidden rounded-xl border border-gray-200 shadow-card">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-left text-xs font-medium uppercase tracking-wide text-ink-faint">
                <tr>
                  <th className="px-5 py-3">Token</th>
                  <th className="px-5 py-3">Release time</th>
                  <th className="px-5 py-3">Shares</th>
                  <th className="px-5 py-3">Phase</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {overview.map((a) => {
                  const phase = assetPhase(a);
                  return (
                    <tr key={a.tokenId}>
                      <td className="px-5 py-4 font-mono text-ink">#{a.tokenId}</td>
                      <td className="px-5 py-4 text-ink-soft">
                        {formatDateTime(a.releaseTime)}
                      </td>
                      <td className="px-5 py-4 text-ink-soft">
                        {a.sharesSubmitted.toString()} / {a.threshold.toString()}
                      </td>
                      <td className="px-5 py-4">
                        <Pill tone={phase.tone}>{phase.label}</Pill>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, mono, truncate }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <dt className="flex-none text-ink-faint">{label}</dt>
      <dd
        className={`text-right text-ink ${mono ? "font-mono text-xs" : ""} ${
          truncate ? "max-w-xs truncate" : "break-all"
        }`}
      >
        {value}
      </dd>
    </div>
  );
}
