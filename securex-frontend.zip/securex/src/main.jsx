import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import { Web3Provider } from "./context/Web3Context.jsx";
import { RoleProvider } from "./context/RoleContext.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <Web3Provider>
        <RoleProvider>
          <App />
        </RoleProvider>
      </Web3Provider>
    </BrowserRouter>
  </React.StrictMode>
);
