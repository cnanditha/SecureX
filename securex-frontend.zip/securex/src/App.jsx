import { Navigate, Route, Routes } from "react-router-dom";
import { useWeb3 } from "./context/Web3Context";
import { useRoles } from "./context/RoleContext";
import Header from "./components/Header";
import Landing from "./pages/Landing";
import AdminDashboard from "./pages/AdminDashboard";
import CustodianDashboard from "./pages/CustodianDashboard";
import ExamCenterDashboard from "./pages/ExamCenterDashboard";
import AuditLog from "./pages/AuditLog";
import PublicVerify from "./pages/PublicVerify";
import { Spinner } from "./components/ui";

function RequireWallet({ children }) {
  const { address } = useWeb3();
  if (!address) return <Navigate to="/" replace />;
  return children;
}

// Blocks access until roles are known, then redirects away if the
// connected address doesn't hold the required role — instead of letting
// the page render and only discovering "you can't do that" from a
// cryptic on-chain revert after clicking a button.
function RequireRole({ allowed, children }) {
  const { loadingRoles } = useRoles();
  if (loadingRoles) {
    return (
      <div className="flex items-center justify-center gap-2 py-24 text-sm text-ink-faint">
        <Spinner className="h-4 w-4" /> Checking your role…
      </div>
    );
  }
  if (!allowed) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { isAdmin, isCustodian, isExamCenter, isPublic } = useRoles();

  return (
    <div className="min-h-screen bg-app-gradient">
      <Header />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route
          path="/admin"
          element={
            <RequireWallet>
              <RequireRole allowed={isAdmin}>
                <AdminDashboard />
              </RequireRole>
            </RequireWallet>
          }
        />
        <Route
          path="/custodian"
          element={
            <RequireWallet>
              <RequireRole allowed={isCustodian}>
                <CustodianDashboard />
              </RequireRole>
            </RequireWallet>
          }
        />
        <Route
          path="/exam-center"
          element={
            <RequireWallet>
              <RequireRole allowed={isAdmin || isExamCenter}>
                <ExamCenterDashboard />
              </RequireRole>
            </RequireWallet>
          }
        />
        <Route
          path="/audit-log"
          element={
            <RequireWallet>
              <AuditLog />
            </RequireWallet>
          }
        />
        <Route
          path="/verify"
          element={
            <RequireWallet>
              <RequireRole allowed={isPublic}>
                <PublicVerify />
              </RequireRole>
            </RequireWallet>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}
