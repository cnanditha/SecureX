// Computes SHA-256 of a File/Blob entirely in the browser using the
// built-in Web Crypto API — no upload needed just to hash something, and
// no extra dependency. Returns a lowercase hex string, matching the
// format the backend and contract both use.
export async function sha256HexOfFile(file) {
  const buffer = await file.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return [...new Uint8Array(digest)]
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}
