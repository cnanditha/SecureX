export function shortAddress(addr, chars = 4) {
  if (!addr) return "";
  return `${addr.slice(0, 2 + chars)}…${addr.slice(-chars)}`;
}

export function txUrl(hash) {
  return `https://sepolia.etherscan.io/tx/${hash}`;
}

export function addressUrl(addr) {
  return `https://sepolia.etherscan.io/address/${addr}`;
}

export function formatDateTime(value) {
  const ms = typeof value === "bigint" ? Number(value) * 1000 : value * 1000;
  return new Date(ms).toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

// Converts a <input type="datetime-local"> value to a unix seconds BigInt.
export function toUnixSeconds(datetimeLocalValue) {
  const ms = new Date(datetimeLocalValue).getTime();
  return BigInt(Math.floor(ms / 1000));
}

export function secondsToCountdown(totalSeconds) {
  if (totalSeconds <= 0) return "00:00:00";
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  const pad = (n) => String(n).padStart(2, "0");
  return days > 0
    ? `${days}d ${pad(hours)}:${pad(minutes)}:${pad(seconds)}`
    : `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}
