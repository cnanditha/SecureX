import { Link, useLocation } from "react-router-dom";
import { useWeb3 } from "../context/Web3Context";
import { useRoles } from "../context/RoleContext";
import { shortAddress } from "../utils/format";

export default function Header() {
  const { address, isSepolia, chainId, connect, disconnect, switchToSepolia } =
    useWeb3();
  const { isAdmin, isCustodian, isExamCenter, isPublic, loadingRoles } = useRoles();
  const location = useLocation();

  const navLinks = [
    isAdmin && { to: "/admin", label: "Admin", accent: "admin" },
    isCustodian && { to: "/custodian", label: "Custodian", accent: "custodian" },
    (isAdmin || isExamCenter) && { to: "/exam-center", label: "Exam Center", accent: "exam" },
    isPublic && { to: "/verify", label: "Public Verify", accent: "public" },
    { to: "/audit-log", label: "Audit Log", accent: "ink" },
  ].filter(Boolean);

  const currentRoleLabel = loadingRoles
    ? null
    : isAdmin
    ? { text: "Admin", tone: "bg-admin-50 text-admin-700" }
    : isCustodian
    ? { text: "Custodian", tone: "bg-custodian-50 text-custodian-700" }
    : isExamCenter
    ? { text: "Exam Center", tone: "bg-exam-50 text-exam-700" }
    : { text: "Public", tone: "bg-public-50 text-public-700" };

  return (
    <header className="sticky top-0 z-20 border-b border-gray-200 bg-white/80 backdrop-blur-md">
      {chainId != null && !isSepolia && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-center text-sm text-amber-800">
          You're connected to the wrong network (chain {chainId.toString()}).{" "}
          <button
            onClick={switchToSepolia}
            className="font-medium underline underline-offset-2 hover:text-amber-900"
          >
            Switch to Sepolia
          </button>
        </div>
      )}
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
        <Link to="/" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-admin-600 via-custodian-600 to-exam-600 text-sm font-bold text-white shadow-sm">
            SX
          </span>
          <span className="text-base font-semibold tracking-tight text-ink">
            SecureX
          </span>
        </Link>

        {address && (
          <nav className="hidden gap-1 md:flex">
            {navLinks.map((link) => {
              const isActive = location.pathname.startsWith(link.to);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`rounded-lg px-3 py-1.5 text-sm font-medium transition-colors ${
                    isActive
                      ? "bg-gray-100 text-ink"
                      : "text-ink-soft hover:bg-gray-50 hover:text-ink"
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
        )}

        <div className="flex items-center gap-3">
          {address ? (
            <>
              {currentRoleLabel && (
                <span
                  className={`hidden items-center rounded-full px-2.5 py-1 text-xs font-medium sm:flex ${currentRoleLabel.tone}`}
                >
                  {currentRoleLabel.text}
                </span>
              )}
              <span
                className={`hidden items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium sm:flex ${
                  isSepolia
                    ? "bg-emerald-50 text-emerald-700"
                    : "bg-amber-50 text-amber-700"
                }`}
              >
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    isSepolia ? "bg-emerald-500" : "bg-amber-500"
                  }`}
                />
                {isSepolia ? "Sepolia" : "Wrong network"}
              </span>
              <span className="rounded-md bg-gray-100 px-3 py-1.5 font-mono text-xs text-ink-soft">
                {shortAddress(address)}
              </span>
              <button
                onClick={disconnect}
                className="text-sm text-ink-faint hover:text-ink-soft"
              >
                Disconnect
              </button>
            </>
          ) : (
            <button
              onClick={connect}
              className="rounded-md bg-ink px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-gray-800"
            >
              Connect Wallet
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
