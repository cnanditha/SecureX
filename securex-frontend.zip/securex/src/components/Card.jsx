const ACCENT_BORDERS = {
  admin: "border-t-2 border-t-admin-600",
  custodian: "border-t-2 border-t-custodian-600",
  exam: "border-t-2 border-t-exam-600",
  public: "border-t-2 border-t-public-600",
};

export default function Card({ children, className = "", accent }) {
  const accentBorder = accent ? ACCENT_BORDERS[accent] ?? "" : "";
  return (
    <div
      className={`bg-white border border-gray-200 rounded-xl shadow-card p-6 ${accentBorder} ${className}`}
    >
      {children}
    </div>
  );
}
