// Small shared, presentation-only UI primitives used across pages.
// Kept deliberately framework-free (no contract logic) so useContract.js
// remains the single place that touches the chain.

const ACCENT_BUTTONS = {
  admin: "bg-admin-600 hover:bg-admin-700 focus-visible:outline-admin-600",
  custodian:
    "bg-custodian-600 hover:bg-custodian-700 focus-visible:outline-custodian-600",
  exam: "bg-exam-600 hover:bg-exam-700 focus-visible:outline-exam-600",
  public: "bg-public-600 hover:bg-public-700 focus-visible:outline-public-600",
};

export function AccentButton({ accent = "admin", children, className = "", ...rest }) {
  return (
    <button
      {...rest}
      className={`inline-flex items-center justify-center gap-2 rounded-md px-4 py-2.5 text-sm font-medium text-white transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${ACCENT_BUTTONS[accent]} ${className}`}
    >
      {children}
    </button>
  );
}

export function Spinner({ className = "h-4 w-4" }) {
  return (
    <svg className={`animate-spin ${className}`} viewBox="0 0 24 24" fill="none">
      <circle
        className="opacity-25"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
      />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
      />
    </svg>
  );
}

export function Pill({ tone = "gray", children }) {
  const tones = {
    gray: "bg-gray-100 text-gray-700",
    green: "bg-emerald-50 text-emerald-700",
    red: "bg-red-50 text-red-700",
    amber: "bg-amber-50 text-amber-700",
    blue: "bg-admin-50 text-admin-700",
    purple: "bg-custodian-50 text-custodian-700",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

export function ErrorBanner({ message }) {
  if (!message) return null;
  return (
    <div className="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
      {message}
    </div>
  );
}

export function EmptyState({ title, description }) {
  return (
    <div className="rounded-xl border border-dashed border-gray-300 px-6 py-14 text-center">
      <p className="text-sm font-medium text-ink">{title}</p>
      {description && (
        <p className="mt-1 text-sm text-ink-faint">{description}</p>
      )}
    </div>
  );
}
