import { useCallback, useMemo } from "react";
import { Contract } from "ethers";
import { useWeb3 } from "../context/Web3Context";
import {
  CONTRACT_ADDRESS,
  CONTRACT_ABI,
  ADMIN_ROLE,
  CUSTODIAN_ROLE,
  DEPLOY_BLOCK,
} from "../contract.config";

// -----------------------------------------------------------------------
// Every piece of contract interaction logic for the app lives here.
// Pages import `useContract()` and call the functions it returns instead
// of touching ethers.Contract directly, so the address/ABI stay defined
// in exactly one place (contract.config.js) and error handling is
// consistent across the app.
// -----------------------------------------------------------------------

export function useContract() {
  const { provider, signer, address } = useWeb3();

  // Read-only contract, backed by the injected provider (works even
  // before the user has an active signer, as long as a wallet is present).
  const readContract = useMemo(() => {
    if (!provider) return null;
    return new Contract(CONTRACT_ADDRESS, CONTRACT_ABI, provider);
  }, [provider]);

  // Write-capable contract, backed by the connected signer.
  const writeContract = useMemo(() => {
    if (!signer) return null;
    return new Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);
  }, [signer]);

  const requireWrite = useCallback(() => {
    if (!writeContract) {
      throw new Error("Connect your wallet before sending a transaction.");
    }
    return writeContract;
  }, [writeContract]);

  const requireRead = useCallback(() => {
    if (!readContract) {
      throw new Error("Connect your wallet to read on-chain data.");
    }
    return readContract;
  }, [readContract]);

  // ---- Role checks -----------------------------------------------------

  const checkRole = useCallback(
    async (role, account) => {
      const c = requireRead();
      return c.hasRole(role, account);
    },
    [requireRead]
  );

  const getRoles = useCallback(
    async (account) => {
      const c = requireRead();
      const [isAdmin, isCustodian] = await Promise.all([
        c.hasRole(ADMIN_ROLE, account),
        c.hasRole(CUSTODIAN_ROLE, account),
      ]);
      return { isAdmin, isCustodian };
    },
    [requireRead]
  );

  // ---- Reads -------------------------------------------------------------

  const getAsset = useCallback(
    async (tokenId) => {
      const c = requireRead();
      const a = await c.assets(tokenId);
      return {
        fileHash: a.fileHash ?? a[0],
        signature: a.signature ?? a[1],
        ipfsCID: a.ipfsCID ?? a[2],
        releaseTime: a.releaseTime ?? a[3],
        sharesSubmitted: a.sharesSubmitted ?? a[4],
        threshold: a.threshold ?? a[5],
        released: a.released ?? a[6],
      };
    },
    [requireRead]
  );

  const getOwner = useCallback(
    async (tokenId) => {
      const c = requireRead();
      return c.ownerOf(tokenId);
    },
    [requireRead]
  );

  // ---- Writes --------------------------------------------------------------

  const createAsset = useCallback(
    async ({ hash, signature, cid, releaseTime, threshold }) => {
      const c = requireWrite();
      const tx = await c.createAsset(hash, signature, cid, releaseTime, threshold);
      const receipt = await tx.wait();
      // Pull the tokenId out of the AssetCreated event in the receipt.
      let tokenId = null;
      for (const log of receipt.logs) {
        try {
          const parsed = c.interface.parseLog(log);
          if (parsed?.name === "AssetCreated") {
            tokenId = parsed.args.tokenId;
            break;
          }
        } catch {
          // not a log this ABI understands — skip
        }
      }
      return { receipt, tokenId, txHash: tx.hash };
    },
    [requireWrite]
  );

  const submitShare = useCallback(
    async (tokenId) => {
      const c = requireWrite();
      const tx = await c.submitShare(tokenId);
      const receipt = await tx.wait();
      return { receipt, txHash: tx.hash };
    },
    [requireWrite]
  );

  const attemptRelease = useCallback(
    async (tokenId, printLocation) => {
      const c = requireWrite();
      const loc = printLocation || address;
      const tx = await c.attemptRelease(tokenId, loc);
      const receipt = await tx.wait();

      // The contract emits DecryptAttempt with success/reason instead of
      // reverting on a logical failure (too early / not enough shares) —
      // so a successfully-mined transaction does NOT mean release actually
      // happened. Decode the event to find out what really occurred.
      let success = false;
      let reason = "";
      for (const log of receipt.logs) {
        try {
          const parsed = c.interface.parseLog(log);
          if (parsed?.name === "DecryptAttempt") {
            success = parsed.args.success;
            reason = parsed.args.reason;
            break;
          }
        } catch {
          // not a log this ABI understands — skip
        }
      }
      return { receipt, txHash: tx.hash, success, reason };
    },
    [requireWrite, address]
  );

  // ---- Events --------------------------------------------------------------

  // Public RPC providers cap eth_getLogs at a 50,000 block range per call.
  // Chunk the query into windows so this works regardless of how far back
  // DEPLOY_BLOCK is from the current tip.
  const CHUNK_SIZE = 45000;

  const queryAllEvents = useCallback(
    async (fromBlock = DEPLOY_BLOCK, toBlock) => {
      const c = requireRead();
      const provider = c.runner?.provider;
      const latest = toBlock ?? (provider ? await provider.getBlockNumber() : "latest");
      const latestNum = typeof latest === "number" ? latest : Number(latest);

      const eventNames = [
        "AssetCreated",
        "ShareSubmitted",
        "DecryptAttempt",
        "AssetReleased",
      ];

      const allLogs = [];
      let windowStart = fromBlock;
      while (windowStart <= latestNum) {
        const windowEnd = Math.min(windowStart + CHUNK_SIZE - 1, latestNum);
        const results = await Promise.all(
          eventNames.map((name) =>
            c.queryFilter(c.filters[name](), windowStart, windowEnd)
          )
        );
        allLogs.push(...results.flat());
        windowStart = windowEnd + 1;
      }

      const flattened = allLogs.map((log) => ({
        eventName: log.eventName ?? log.fragment?.name,
        args: log.args,
        blockNumber: log.blockNumber,
        transactionHash: log.transactionHash,
        logIndex: log.index,
      }));
      flattened.sort((a, b) => a.blockNumber - b.blockNumber || a.logIndex - b.logIndex);
      return flattened;
    },
    [requireRead]
  );

  return {
    readContract,
    writeContract,
    checkRole,
    getRoles,
    getAsset,
    getOwner,
    createAsset,
    submitShare,
    attemptRelease,
    queryAllEvents,
  };
}
