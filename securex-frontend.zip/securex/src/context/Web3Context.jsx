import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { BrowserProvider } from "ethers";
import { SEPOLIA_CHAIN_ID, SEPOLIA_PARAMS } from "../contract.config";

const Web3Context = createContext(null);

export function Web3Provider({ children }) {
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [address, setAddress] = useState(null);
  const [chainId, setChainId] = useState(null);
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState(null);

  const hasWallet = typeof window !== "undefined" && !!window.ethereum;
  const isSepolia = chainId != null && chainId === SEPOLIA_CHAIN_ID;

  const refreshFromProvider = useCallback(async (browserProvider) => {
    const network = await browserProvider.getNetwork();
    setChainId(network.chainId);
    const accounts = await browserProvider.listAccounts();
    if (accounts.length > 0) {
      const s = await browserProvider.getSigner();
      setSigner(s);
      setAddress(await s.getAddress());
    } else {
      setSigner(null);
      setAddress(null);
    }
  }, []);

  const connect = useCallback(async () => {
    setError(null);
    if (!window.ethereum) {
      setError("No wallet found. Install MetaMask to continue.");
      return;
    }
    setConnecting(true);
    try {
      const browserProvider = new BrowserProvider(window.ethereum);
      await browserProvider.send("eth_requestAccounts", []);
      setProvider(browserProvider);
      await refreshFromProvider(browserProvider);
    } catch (err) {
      setError(err?.info?.error?.message || err?.message || "Connection failed.");
    } finally {
      setConnecting(false);
    }
  }, [refreshFromProvider]);

  const disconnect = useCallback(() => {
    setProvider(null);
    setSigner(null);
    setAddress(null);
    setChainId(null);
  }, []);

  const switchToSepolia = useCallback(async () => {
    if (!window.ethereum) return;
    try {
      await window.ethereum.request({
        method: "wallet_switchEthereumChain",
        params: [{ chainId: SEPOLIA_PARAMS.chainId }],
      });
    } catch (switchErr) {
      // 4902 = chain not added to wallet yet
      if (switchErr?.code === 4902) {
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [SEPOLIA_PARAMS],
        });
      } else {
        setError(switchErr?.message || "Could not switch network.");
      }
    }
  }, []);

  // React to MetaMask account/network changes.
  useEffect(() => {
    if (!window.ethereum) return;
    const handleAccountsChanged = () => {
      if (provider) refreshFromProvider(provider);
    };
    const handleChainChanged = () => {
      window.location.reload();
    };
    window.ethereum.on?.("accountsChanged", handleAccountsChanged);
    window.ethereum.on?.("chainChanged", handleChainChanged);
    return () => {
      window.ethereum.removeListener?.("accountsChanged", handleAccountsChanged);
      window.ethereum.removeListener?.("chainChanged", handleChainChanged);
    };
  }, [provider, refreshFromProvider]);

  // Silently reconnect if the site is already authorized.
  useEffect(() => {
    if (!window.ethereum) return;
    (async () => {
      const browserProvider = new BrowserProvider(window.ethereum);
      const accounts = await browserProvider.listAccounts();
      if (accounts.length > 0) {
        setProvider(browserProvider);
        await refreshFromProvider(browserProvider);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const value = useMemo(
    () => ({
      provider,
      signer,
      address,
      chainId,
      isSepolia,
      hasWallet,
      connecting,
      error,
      connect,
      disconnect,
      switchToSepolia,
    }),
    [
      provider,
      signer,
      address,
      chainId,
      isSepolia,
      hasWallet,
      connecting,
      error,
      connect,
      disconnect,
      switchToSepolia,
    ]
  );

  return <Web3Context.Provider value={value}>{children}</Web3Context.Provider>;
}

export function useWeb3() {
  const ctx = useContext(Web3Context);
  if (!ctx) throw new Error("useWeb3 must be used within a Web3Provider");
  return ctx;
}
