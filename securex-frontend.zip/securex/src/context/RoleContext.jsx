import { createContext, useContext, useEffect, useState } from "react";
import { useWeb3 } from "./Web3Context";
import { useContract } from "../hooks/useContract";
import { EXAM_CENTER_ADDRESS } from "../contract.config";

// -----------------------------------------------------------------------
// Computes every role ONCE per connected address and shares it everywhere
// (route guards, nav links, page-level checks) instead of every page
// re-querying the contract independently.
//
// Four distinct, mutually exclusive roles, each seeing only its own
// dashboard + the Audit Log:
//   - isAdmin        on-chain ADMIN_ROLE
//   - isCustodian    on-chain CUSTODIAN_ROLE
//   - isExamCenter   address matches the configured EXAM_CENTER_ADDRESS
//                    (frontend-only — the contract itself has no
//                    "exam center" role, since attemptRelease() is
//                    intentionally open to anyone)
//   - isPublic       anyone matching none of the above — a genuinely
//                     unaffiliated wallet, e.g. laptop 6's demo address
// -----------------------------------------------------------------------

const RoleContext = createContext(null);

export function RoleProvider({ children }) {
  const { address, isSepolia } = useWeb3();
  const { getRoles } = useContract();

  const [isAdmin, setIsAdmin] = useState(false);
  const [isCustodian, setIsCustodian] = useState(false);
  const [loadingRoles, setLoadingRoles] = useState(false);
  const [roleError, setRoleError] = useState(null);

  useEffect(() => {
    if (!address || !isSepolia) {
      setIsAdmin(false);
      setIsCustodian(false);
      return;
    }
    let cancelled = false;
    (async () => {
      setLoadingRoles(true);
      setRoleError(null);
      try {
        const roles = await getRoles(address);
        if (cancelled) return;
        setIsAdmin(roles.isAdmin);
        setIsCustodian(roles.isCustodian);
      } catch (err) {
        if (!cancelled) {
          setRoleError(err?.message || "Could not read roles from the contract.");
        }
      } finally {
        if (!cancelled) setLoadingRoles(false);
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [address, isSepolia]);

  const isExamCenter =
    !isAdmin &&
    !isCustodian &&
    !!EXAM_CENTER_ADDRESS &&
    !!address &&
    address.toLowerCase() === EXAM_CENTER_ADDRESS;

  const isPublic = !isAdmin && !isCustodian && !isExamCenter;

  const value = {
    isAdmin,
    isCustodian,
    isExamCenter,
    isPublic,
    loadingRoles,
    roleError,
  };

  return <RoleContext.Provider value={value}>{children}</RoleContext.Provider>;
}

export function useRoles() {
  const ctx = useContext(RoleContext);
  if (!ctx) throw new Error("useRoles must be used within a RoleProvider");
  return ctx;
}
