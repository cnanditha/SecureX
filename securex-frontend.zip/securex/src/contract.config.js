import { id as keccakId } from "ethers";

// -----------------------------------------------------------------------
// SecureX contract configuration.
// This is the ONLY place the contract address, ABI, and role IDs are
// defined. src/hooks/useContract.js imports from here exclusively —
// do not redeclare any of this in a page or component.
// -----------------------------------------------------------------------

// Deployed SecureX contract address on Sepolia.
// Override via .env: VITE_CONTRACT_ADDRESS=0x...
export const CONTRACT_ADDRESS =
  import.meta.env.VITE_CONTRACT_ADDRESS ||
  "0x0000000000000000000000000000000000000000";

export const SEPOLIA_CHAIN_ID = 11155111n; // ethers v6 network.chainId is a BigInt
export const SEPOLIA_CHAIN_ID_HEX = "0xaa36a7";

export const SEPOLIA_PARAMS = {
  chainId: SEPOLIA_CHAIN_ID_HEX,
  chainName: "Sepolia",
  nativeCurrency: { name: "Sepolia ETH", symbol: "ETH", decimals: 18 },
  rpcUrls: ["https://ethereum-sepolia-rpc.publicnode.com"],
  blockExplorerUrls: ["https://sepolia.etherscan.io"],
};

// The block your contract was deployed at. Event queries start here
// instead of block 0 — public RPC providers cap eth_getLogs at a 50,000
// block range per call, and Sepolia is already millions of blocks tall.
// Override via .env: VITE_DEPLOY_BLOCK=1234567
export const DEPLOY_BLOCK = Number(import.meta.env.VITE_DEPLOY_BLOCK || 0);

// AccessControl role identifiers. Standard OpenZeppelin pattern is
// keccak256("ROLE_NAME"); ethers' id() helper does exactly that.
// If your deployment defines these differently, replace the two lines below.
export const ADMIN_ROLE = keccakId("ADMIN_ROLE");
export const CUSTODIAN_ROLE = keccakId("CUSTODIAN_ROLE");

export const CONTRACT_ABI = [
  // --- Writes ---
  "function createAsset(string hash, string signature, string cid, uint256 releaseTime, uint256 threshold) returns (uint256)",
  "function submitShare(uint256 tokenId)",
  "function attemptRelease(uint256 tokenId, address printLocation) returns (bool)",

  // --- Reads ---
  "function hasRole(bytes32 role, address account) view returns (bool)",
  "function assets(uint256 tokenId) view returns (string fileHash, string signature, string ipfsCID, uint256 releaseTime, uint256 sharesSubmitted, uint256 threshold, bool released)",
  "function ownerOf(uint256 tokenId) view returns (address)",

  // --- Events ---
  "event AssetCreated(uint256 tokenId, string fileHash, uint256 releaseTime)",
  "event ShareSubmitted(uint256 tokenId, address custodian, uint256 totalSoFar)",
  "event DecryptAttempt(uint256 tokenId, address caller, bool success, string reason)",
  "event AssetReleased(uint256 tokenId, address to)",
];

// The Exam Center's own wallet address. The contract has no on-chain
// "exam center" role (attemptRelease is intentionally open to anyone) —
// so this is a frontend-only configuration that tells the app "this
// specific address is the exam center's operator," distinguishing it
// from a random public/verifier wallet. Override via .env:
// VITE_EXAM_CENTER_ADDRESS=0x...
export const EXAM_CENTER_ADDRESS = (
  import.meta.env.VITE_EXAM_CENTER_ADDRESS || ""
).toLowerCase();

// Backend API base — the Node/Express (or similar) service that performs
// hashing, signing, AES + Shamir + ECC wrapping, and IPFS upload/download.
export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "/api";
