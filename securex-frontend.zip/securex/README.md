# SecureAsset — Frontend

React (Vite) + Tailwind CSS frontend for the SecureAsset exam-paper chain of
custody system. Talks to a deployed Solidity contract on Ethereum Sepolia via
ethers.js v6 and MetaMask, plus a backend API for the off-chain crypto work.

## Setup

```bash
npm install
cp .env.example .env
# edit .env: set VITE_CONTRACT_ADDRESS to your deployed contract
npm run dev
```

Open the printed local URL (default `http://localhost:5173`) with MetaMask
installed and set to the Sepolia test network.

## Project structure

```
src/
  contract.config.js       # Contract address, ABI, role IDs, network + API constants
                            #   -> the ONLY place these are defined
  hooks/useContract.js      # All contract reads/writes/event queries go through here
  context/Web3Context.jsx   # MetaMask connect/disconnect, signer, network detection
  components/
    Header.jsx               # Persistent header: wallet address, network warning, nav
    Card.jsx, ui.jsx          # Shared presentational primitives
  pages/
    Landing.jsx               # Connect wallet -> role check -> redirect
    AdminDashboard.jsx        # Upload + create asset (blue)
    CustodianDashboard.jsx    # Pending share submissions (purple)
    ExamCenterDashboard.jsx   # Countdown, release, decrypt & verify (green)
    AuditLog.jsx               # Chronological event timeline
```

Every page imports `useContract()` from `hooks/useContract.js` for chain
interaction — no page constructs its own `ethers.Contract` instance, so the
address/ABI stay defined in exactly one place.

## Roles

Role IDs are computed as `keccak256("ADMIN_ROLE")` / `keccak256("CUSTODIAN_ROLE")`
via `ethers.id(...)`, matching the standard OpenZeppelin AccessControl
convention. If your deployed contract defines these role identifiers
differently, update `ADMIN_ROLE` / `CUSTODIAN_ROLE` in `contract.config.js`
(the single source of truth) — nowhere else needs to change.

## Backend API contract

The frontend expects a backend at `VITE_API_BASE_URL` (default `/api`) with
two endpoints. The frontend only calls the chain directly for the
`createAsset`, `submitShare`, and `attemptRelease` transactions themselves —
everything off-chain (hashing, signing, AES, Shamir splitting, ECC wrapping,
IPFS upload/download, decryption, verification) is the backend's job.

### `POST /api/create-asset`

Request: `multipart/form-data`
- `file` — the exam paper
- `releaseTime` — unix seconds (string)
- `threshold` — required share count (string)
- `adminAddress` — connected wallet address

Response: `200 application/json`
```json
{ "hash": "0x...", "signature": "0x...", "cid": "Qm..." }
```
The frontend then calls `createAsset(hash, signature, cid, releaseTime, threshold)`
on-chain directly from the admin's connected wallet.

### `POST /api/decrypt-asset`

Request: `application/json`
```json
{ "tokenId": "4", "requesterAddress": "0x..." }
```

Response: `200 application/json`
```json
{
  "hashMatch": true,
  "signatureValid": true,
  "downloadUrl": "https://.../decrypted-file"
}
```
`downloadUrl` is only rendered when both checks pass.

## Notes on discovering token IDs

The contract has no "list all assets" method, so the Custodian Dashboard and
Audit Log both discover token IDs by querying `AssetCreated` events via
`useContract().queryAllEvents()` and working from there. This is the standard
pattern for enumerable on-chain assets that don't expose an index.
