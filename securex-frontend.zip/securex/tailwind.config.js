/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        admin: {
          DEFAULT: "#2563eb", // blue
          50: "#eff6ff",
          100: "#dbeafe",
          600: "#2563eb",
          700: "#1d4ed8",
        },
        custodian: {
          DEFAULT: "#7c3aed", // purple
          50: "#f5f3ff",
          100: "#ede9fe",
          600: "#7c3aed",
          700: "#6d28d9",
        },
        exam: {
          DEFAULT: "#059669", // green
          50: "#ecfdf5",
          100: "#d1fae5",
          600: "#059669",
          700: "#047857",
        },
        public: {
          DEFAULT: "#0891b2", // cyan — kept distinct from the three role colors
          50: "#ecfeff",
          100: "#cffafe",
          600: "#0891b2",
          700: "#0e7490",
        },
        ink: {
          DEFAULT: "#111827",
          soft: "#4b5563",
          faint: "#9ca3af",
        },
      },
      fontFamily: {
        sans: [
          "Inter",
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "Segoe UI",
          "Roboto",
          "sans-serif",
        ],
        mono: [
          "JetBrains Mono",
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "monospace",
        ],
      },
      boxShadow: {
        card: "0 1px 2px rgba(17, 24, 39, 0.06), 0 1px 3px rgba(17, 24, 39, 0.08)",
      },
      backgroundImage: {
        "app-gradient":
          "radial-gradient(ellipse 80% 50% at 50% -10%, rgba(37,99,235,0.06), transparent), radial-gradient(ellipse 60% 40% at 100% 0%, rgba(124,58,237,0.05), transparent), radial-gradient(ellipse 60% 40% at 0% 10%, rgba(5,150,105,0.05), transparent)",
      },
    },
  },
  plugins: [],
};
